var mongoose = require("mongoose");


//SCHEMA SETUP
var petSchema = new mongoose.Schema({
   name: String,
   image: String,
   breed: String,
   description: String,
   location: String,
   contact: String,
   author: {
      id: {
         type: mongoose.Schema.Types.ObjectId,
         ref: "User"
      },
      username: String
   }
});

module.exports = mongoose.model("Pet", petSchema);
