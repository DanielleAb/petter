var express = require("express");
var router  = express.Router({mergeParams: true});
var Pet = require("../models/pet");

var middleware = require("../middleware");

router.get("/", function(req,res){
    Pet.find({}, function(err, allPets){
       if(err){
           console.log(err);
       }else{
            res.render("pets/index", {pets: allPets});
       }
    });
});

router.post("/", middleware.isLoggedIn, function(req,res){
   var name = req.body.name;
   var image = req.body.image;
   var breed = req.body.breed;
   var desc = req.body.description;
   var location = req.body.location;
   var contact = req.body.contact;
   var author = {
       id: req.user._id,
       username: req.user.username
   }
   var newPet = {name:name, image:image, breed:breed, description: desc, location:location, author: author, contact:contact};
    Pet.create(newPet, function(err, newlyCreated){
       if(err){
            console.log(err);   
       } else{
           console.log(newlyCreated);
            res.redirect("/pets");
        }
    });
 });

router.get("/new", middleware.isLoggedIn, function(req,res){
    res.render("pets/new");
});


router.get("/:id", function(req,res){
    Pet.findById(req.params.id, function(err, foundPet){
        if(err){
            console.log(err);
        } else{
            res.render("pets/show", {pet: foundPet});
        }
    });
});

router.get("/:id/edit", middleware.checkPetOwnership, function(req,res){
  
         Pet.findById(req.params.id, function(err, foundPet){
            res.render("pets/edit", {pet: foundPet});
         });
              
});
router.put("/:id", middleware.checkPetOwnership, function(req,res){
    Pet.findByIdAndUpdate(req.params.id, req.body.pet , function(err, updatedPet){
      if(err){
          res.redirect("/pets");
      } else {
          res.redirect("/pets/" + req.params.id);
      }
   });
});

router.delete("/:id", middleware.checkPetOwnership, function(req,res){
   Pet.findByIdAndRemove(req.params.id, function(err){
       if(err){
           res.redirect("/pets");
       } else {
           res.redirect("/pets");
       }
   });
});




module.exports = router;