var express       = require("express"),
    app           = express(),
    bodyParser    = require("body-parser"),
    mongoose      = require("mongoose"),
    passport      = require ("passport"),
    methodOverride = require("method-override"),
    localStrategy = require("passport-local"),
    Pet    = require("./models/pet"),
    User          = require("./models/user");

var petRoutes = require("./routes/pets"),
    indexRoutes      = require("./routes/index");   

// mongoose.connect("mongodb://localhost/petter");
mongoose.connect("mongodb://danielle:rusty@ds235169.mlab.com:35169/petter");

app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(bodyParser.urlencoded({extended: true}));
app.use(methodOverride("_method"));

//PASSORT CONFIGURATION
app.use(require("express-session")({
   secret:"anything that we want. still dont know when we use it" ,
   resave: false,
   saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());


app.use(function(req, res, next){
   res.locals.currentUser = req.user; 
   console.log(req.user);
   next();
});



app.use(indexRoutes); 
app.use("/pets", petRoutes);

app.listen(process.env.PORT, process.env.IP, function(){
   console.log("The Petter Server Has Started");
});
 